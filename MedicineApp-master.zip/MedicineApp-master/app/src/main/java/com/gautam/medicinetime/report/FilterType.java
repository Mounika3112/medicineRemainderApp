package com.gautam.medicinetime.report;

/**
 * Created by gautam on 13/07/17.
 */

public enum  FilterType {

    ALL_MEDICINES,

    TAKEN_MEDICINES,

    IGNORED_MEDICINES
}
